export const INVEST_RECOMMEND_API =  import.meta.env.VITE_APP_API_INVEST_RECOMMEND
export const RECENT_INVEST_API = import.meta.env.VITE_APP_API_INVEST_RECENT
export const NEWS_API = import.meta.env.VITE_APP_API_NEWS
export const STATS_API = import.meta.env.VITE_APP_API_STATS
export const TREND_STOCKS_API = import.meta.env.VITE_APP_API_TREND_STOCKS
export const FAQ_API = import.meta.env.VITE_APP_API_FAQ
export const NOTIFICATIONS_API = import.meta.env.VITE_APP_API_NOTIFICATIONS