import React from 'react'

const AllNotif = () => {
  return (
    <div>AllNotif</div>
  )
}

export default AllNotif